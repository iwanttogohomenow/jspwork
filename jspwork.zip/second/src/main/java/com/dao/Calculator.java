package com.dao;

public class Calculator {
public static int process(int a) {
   
   return a*a*a;
   
}
}